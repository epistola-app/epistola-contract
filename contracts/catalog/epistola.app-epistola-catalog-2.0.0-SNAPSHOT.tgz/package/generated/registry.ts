/* Generated from registry/*.json -- do not edit manually. */
import type { ComponentRegistry } from './component-manifest.js';
import type { StyleRegistry } from './style-registry.js';

export const componentRegistry: ComponentRegistry = {
  "schemaVersion": 1,
  "components": [
    {
      "type": "root",
      "label": "Document Root",
      "icon": "file-text",
      "category": "layout",
      "hidden": false,
      "slots": [
        {
          "name": "children"
        }
      ],
      "allowedChildren": {
        "mode": "denylist",
        "types": [
          "root"
        ]
      },
      "applicableStyles": [],
      "inspector": [],
      "examples": [
        {
          "name": "document-skeleton",
          "description": "The top-level node of every template document. Exactly one root exists per document (doc.root points at it) — it is created with the document, never inserted manually. Its single \"children\" slot holds the document body in render order.",
          "fragment": {
            "rootNodeId": "n-root-doc",
            "nodes": {
              "n-root-doc": {
                "id": "n-root-doc",
                "type": "root",
                "slots": [
                  "s-root-doc-children"
                ]
              },
              "n-root-doc-heading": {
                "id": "n-root-doc-heading",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "heading",
                        "attrs": {
                          "level": 1
                        },
                        "content": [
                          {
                            "type": "text",
                            "text": "Order confirmation"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-root-doc-body": {
                "id": "n-root-doc-body",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Thank you for your order, "
                          },
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "customer.name"
                            }
                          },
                          {
                            "type": "text",
                            "text": "."
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-root-doc-children": {
                "id": "s-root-doc-children",
                "nodeId": "n-root-doc",
                "name": "children",
                "children": [
                  "n-root-doc-heading",
                  "n-root-doc-body"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "text",
      "label": "Text",
      "icon": "type",
      "category": "content",
      "hidden": false,
      "slots": [],
      "allowedChildren": {
        "mode": "none"
      },
      "applicableStyles": "all",
      "inspector": [],
      "defaultStyles": {
        "marginBottom": "1.5sp",
        "listItemSpacing": "0.5sp"
      },
      "defaultProps": {
        "content": null
      },
      "examples": [
        {
          "name": "minimal",
          "description": "Plain paragraph with literal text content.",
          "fragment": {
            "rootNodeId": "n-text-minimal",
            "nodes": {
              "n-text-minimal": {
                "id": "n-text-minimal",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Hello, world!"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {}
          }
        },
        {
          "name": "with-expression",
          "description": "Text with an inline data expression — references a field on the input data via {{ ... }}.",
          "fragment": {
            "rootNodeId": "n-text-with-expression",
            "nodes": {
              "n-text-with-expression": {
                "id": "n-text-with-expression",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Dear "
                          },
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "recipient.name"
                            }
                          },
                          {
                            "type": "text",
                            "text": ","
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {}
          }
        },
        {
          "name": "heading",
          "description": "A level-1 heading. Use the heading node type within content for h1..h6.",
          "fragment": {
            "rootNodeId": "n-text-heading",
            "nodes": {
              "n-text-heading": {
                "id": "n-text-heading",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "heading",
                        "attrs": {
                          "level": 1
                        },
                        "content": [
                          {
                            "type": "text",
                            "text": "Invoice"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {}
          }
        }
      ]
    },
    {
      "type": "richTextVariable",
      "label": "Rich Text Block",
      "icon": "type",
      "category": "content",
      "hidden": false,
      "slots": [],
      "allowedChildren": {
        "mode": "none"
      },
      "applicableStyles": "all",
      "inspector": [
        {
          "key": "binding",
          "label": "Binding",
          "type": "expression",
          "defaultValue": ""
        }
      ],
      "defaultStyles": {
        "marginBottom": "1.5sp",
        "listItemSpacing": "0.5sp"
      },
      "defaultProps": {
        "binding": ""
      },
      "examples": [
        {
          "name": "minimal",
          "description": "Renders the rich-text value bound at the given data path as block content (paragraphs, lists, marks).",
          "fragment": {
            "rootNodeId": "n-richtextvar-minimal",
            "nodes": {
              "n-richtextvar-minimal": {
                "id": "n-richtextvar-minimal",
                "type": "richTextVariable",
                "slots": [],
                "props": {
                  "binding": "customer.bio"
                }
              }
            },
            "slots": {}
          }
        }
      ]
    },
    {
      "type": "container",
      "label": "Container",
      "icon": "box",
      "category": "layout",
      "hidden": false,
      "slots": [
        {
          "name": "children"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "fontFamily",
        "fontSize",
        "fontWeight",
        "fontStyle",
        "color",
        "lineHeight",
        "letterSpacing",
        "textAlign",
        "padding",
        "margin",
        "marginBottom",
        "listItemSpacing",
        "backgroundColor",
        "border",
        "borderRadius",
        "width",
        "keepTogether",
        "keepWithNext",
        "minHeight"
      ],
      "inspector": [],
      "defaultStyles": {
        "marginBottom": "1.5sp"
      },
      "examples": [
        {
          "name": "with-children",
          "description": "Container holding a heading followed by a paragraph — typical for grouping a section.",
          "fragment": {
            "rootNodeId": "n-container-with-children",
            "nodes": {
              "n-container-with-children": {
                "id": "n-container-with-children",
                "type": "container",
                "slots": [
                  "s-container-with-children"
                ]
              },
              "n-container-with-children-heading": {
                "id": "n-container-with-children-heading",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "heading",
                        "attrs": {
                          "level": 2
                        },
                        "content": [
                          {
                            "type": "text",
                            "text": "Section title"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-container-with-children-body": {
                "id": "n-container-with-children-body",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Section body content goes here."
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-container-with-children": {
                "id": "s-container-with-children",
                "nodeId": "n-container-with-children",
                "name": "children",
                "children": [
                  "n-container-with-children-heading",
                  "n-container-with-children-body"
                ]
              }
            }
          }
        },
        {
          "name": "styled-box",
          "description": "Container used purely as a styled box — bordered + padded with no children.",
          "fragment": {
            "rootNodeId": "n-container-styled",
            "nodes": {
              "n-container-styled": {
                "id": "n-container-styled",
                "type": "container",
                "slots": [
                  "s-container-styled-children"
                ],
                "styles": {
                  "border": "1pt solid #cbd5e1",
                  "padding": "8pt",
                  "borderRadius": "4pt"
                }
              }
            },
            "slots": {
              "s-container-styled-children": {
                "id": "s-container-styled-children",
                "nodeId": "n-container-styled",
                "name": "children",
                "children": []
              }
            }
          }
        },
        {
          "name": "fixed-height-card",
          "description": "A card at least 72pt tall, such as one tile in a row of overview cards. minHeight is a minimum: the card grows when its content is taller and never clips.",
          "fragment": {
            "rootNodeId": "n-container-card",
            "nodes": {
              "n-container-card": {
                "id": "n-container-card",
                "type": "container",
                "slots": [
                  "s-container-card-children"
                ],
                "styles": {
                  "minHeight": "72pt",
                  "padding": "8pt",
                  "backgroundColor": "#eff6ff",
                  "borderRadius": "4pt"
                }
              },
              "n-container-card-text": {
                "id": "n-container-card-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Open requests"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-container-card-children": {
                "id": "s-container-card-children",
                "nodeId": "n-container-card",
                "name": "children",
                "children": [
                  "n-container-card-text"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "columns",
      "label": "Columns",
      "icon": "columns-2",
      "category": "layout",
      "hidden": false,
      "slots": [
        {
          "name": "column-{i}",
          "dynamic": true
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "marginBottom",
        "backgroundColor",
        "border",
        "borderRadius",
        "keepTogether",
        "keepWithNext"
      ],
      "styleMaps": [
        {
          "key": "columnStyles",
          "label": "Column Styles",
          "description": "Styles for each column, in column order: entry i styles slot column-i. The columns are counted by the columnSizes prop, and the array may be shorter than it but not longer; use {} for a column without styles. The columns in a row are equally tall, so a column's background and border fill the height of the row.",
          "shape": "indexed",
          "applicableStyles": [
            "backgroundColor",
            "padding",
            "border",
            "verticalAlign"
          ]
        }
      ],
      "inspector": [
        {
          "key": "gap",
          "label": "Gap",
          "type": "number",
          "defaultValue": 0
        }
      ],
      "defaultStyles": {
        "marginBottom": "1.5sp"
      },
      "defaultProps": {
        "columnSizes": [
          1,
          1
        ],
        "gap": 0
      },
      "examples": [
        {
          "name": "two-equal",
          "description": "A 50/50 split — two equal-width columns, no gap.",
          "fragment": {
            "rootNodeId": "n-columns-equal",
            "nodes": {
              "n-columns-equal": {
                "id": "n-columns-equal",
                "type": "columns",
                "slots": [
                  "s-columns-equal-0",
                  "s-columns-equal-1"
                ],
                "props": {
                  "columnSizes": [
                    1,
                    1
                  ],
                  "gap": 0
                }
              },
              "n-columns-equal-left": {
                "id": "n-columns-equal-left",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Left column"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-columns-equal-right": {
                "id": "n-columns-equal-right",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Right column"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-columns-equal-0": {
                "id": "s-columns-equal-0",
                "nodeId": "n-columns-equal",
                "name": "column-0",
                "children": [
                  "n-columns-equal-left"
                ]
              },
              "s-columns-equal-1": {
                "id": "s-columns-equal-1",
                "nodeId": "n-columns-equal",
                "name": "column-1",
                "children": [
                  "n-columns-equal-right"
                ]
              }
            }
          }
        },
        {
          "name": "one-third-two-thirds",
          "description": "A 1/3 + 2/3 split with a 12pt gap. columnSizes are flex weights, not absolute widths.",
          "fragment": {
            "rootNodeId": "n-columns-uneven",
            "nodes": {
              "n-columns-uneven": {
                "id": "n-columns-uneven",
                "type": "columns",
                "slots": [
                  "s-columns-uneven-0",
                  "s-columns-uneven-1"
                ],
                "props": {
                  "columnSizes": [
                    1,
                    2
                  ],
                  "gap": 12
                }
              }
            },
            "slots": {
              "s-columns-uneven-0": {
                "id": "s-columns-uneven-0",
                "nodeId": "n-columns-uneven",
                "name": "column-0",
                "children": []
              },
              "s-columns-uneven-1": {
                "id": "s-columns-uneven-1",
                "nodeId": "n-columns-uneven",
                "name": "column-1",
                "children": []
              }
            }
          }
        },
        {
          "name": "side-bar",
          "description": "A shaded side bar beside the main column. columnStyles gives each column its own background, padding and vertical alignment, and both columns are as tall as the row.",
          "fragment": {
            "rootNodeId": "n-columns-sidebar",
            "nodes": {
              "n-columns-sidebar": {
                "id": "n-columns-sidebar",
                "type": "columns",
                "slots": [
                  "s-columns-sidebar-0",
                  "s-columns-sidebar-1"
                ],
                "props": {
                  "columnSizes": [
                    1,
                    3
                  ],
                  "gap": 0,
                  "columnStyles": [
                    {
                      "backgroundColor": "#1e3a8a",
                      "padding": "3sp",
                      "verticalAlign": "middle"
                    },
                    {
                      "padding": "3sp",
                      "borderLeft": "1pt solid #cbd5e1"
                    }
                  ]
                }
              }
            },
            "slots": {
              "s-columns-sidebar-0": {
                "id": "s-columns-sidebar-0",
                "nodeId": "n-columns-sidebar",
                "name": "column-0",
                "children": []
              },
              "s-columns-sidebar-1": {
                "id": "s-columns-sidebar-1",
                "nodeId": "n-columns-sidebar",
                "name": "column-1",
                "children": []
              }
            }
          }
        }
      ]
    },
    {
      "type": "table",
      "label": "Table",
      "icon": "table",
      "category": "layout",
      "hidden": false,
      "slots": [
        {
          "name": "cell-{r}-{c}",
          "dynamic": true
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "marginTop",
        "marginBottom",
        "backgroundColor",
        "border",
        "borderRadius",
        "keepTogether",
        "keepWithNext"
      ],
      "styleMaps": [
        {
          "key": "cellStyles",
          "label": "Cell Styles",
          "description": "Styles for single cells, keyed '<row>-<col>' with 0-based indexes counted over the table's rows and columns props. A merged cell takes the styles of its top-left cell.",
          "shape": "keyed",
          "keyPattern": "^\\d+-\\d+$",
          "applicableStyles": [
            "backgroundColor",
            "padding",
            "border",
            "verticalAlign"
          ]
        }
      ],
      "inspector": [],
      "defaultStyles": {
        "marginBottom": "1.5sp"
      },
      "defaultProps": {
        "rows": 2,
        "columns": 2,
        "columnWidths": [
          50,
          50
        ],
        "headerRows": 0,
        "merges": []
      },
      "examples": [
        {
          "name": "2x2-with-header",
          "description": "A 2x2 table with the first row as a header, shaded and vertically centred through cellStyles. Cells live in slots named cell-<row>-<col>; cellStyles keys use the same 0-based <row>-<col>.",
          "fragment": {
            "rootNodeId": "n-table-2x2",
            "nodes": {
              "n-table-2x2": {
                "id": "n-table-2x2",
                "type": "table",
                "slots": [
                  "s-table-2x2-cell-0-0",
                  "s-table-2x2-cell-0-1",
                  "s-table-2x2-cell-1-0",
                  "s-table-2x2-cell-1-1"
                ],
                "props": {
                  "rows": 2,
                  "columns": 2,
                  "columnWidths": [
                    50,
                    50
                  ],
                  "headerRows": 1,
                  "merges": [],
                  "cellStyles": {
                    "0-0": {
                      "backgroundColor": "#f1f5f9",
                      "verticalAlign": "middle"
                    },
                    "0-1": {
                      "backgroundColor": "#f1f5f9",
                      "verticalAlign": "middle",
                      "paddingRight": "2sp"
                    }
                  }
                }
              },
              "n-table-2x2-h0": {
                "id": "n-table-2x2-h0",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Name"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-table-2x2-h1": {
                "id": "n-table-2x2-h1",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Total"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-table-2x2-c00": {
                "id": "n-table-2x2-c00",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Subtotal"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-table-2x2-c01": {
                "id": "n-table-2x2-c01",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "subtotal"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-table-2x2-cell-0-0": {
                "id": "s-table-2x2-cell-0-0",
                "nodeId": "n-table-2x2",
                "name": "cell-0-0",
                "children": [
                  "n-table-2x2-h0"
                ]
              },
              "s-table-2x2-cell-0-1": {
                "id": "s-table-2x2-cell-0-1",
                "nodeId": "n-table-2x2",
                "name": "cell-0-1",
                "children": [
                  "n-table-2x2-h1"
                ]
              },
              "s-table-2x2-cell-1-0": {
                "id": "s-table-2x2-cell-1-0",
                "nodeId": "n-table-2x2",
                "name": "cell-1-0",
                "children": [
                  "n-table-2x2-c00"
                ]
              },
              "s-table-2x2-cell-1-1": {
                "id": "s-table-2x2-cell-1-1",
                "nodeId": "n-table-2x2",
                "name": "cell-1-1",
                "children": [
                  "n-table-2x2-c01"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "datatable",
      "label": "Data Table",
      "icon": "sheet",
      "category": "logic",
      "hidden": false,
      "slots": [
        {
          "name": "columns"
        }
      ],
      "allowedChildren": {
        "mode": "allowlist",
        "types": [
          "datatable-column"
        ]
      },
      "applicableStyles": [
        "padding",
        "margin",
        "marginBottom",
        "backgroundColor",
        "border",
        "borderRadius",
        "keepTogether",
        "keepWithNext"
      ],
      "inspector": [
        {
          "key": "expression.raw",
          "label": "Data Expression",
          "type": "expression"
        },
        {
          "key": "itemAlias",
          "label": "Item Alias",
          "type": "text",
          "defaultValue": "item"
        },
        {
          "key": "indexAlias",
          "label": "Index Alias",
          "type": "text"
        },
        {
          "key": "borderStyle",
          "label": "Border Style",
          "type": "select",
          "options": [
            {
              "label": "None",
              "value": "none"
            },
            {
              "label": "All",
              "value": "all"
            },
            {
              "label": "Horizontal",
              "value": "horizontal"
            },
            {
              "label": "Vertical",
              "value": "vertical"
            }
          ],
          "defaultValue": "all"
        },
        {
          "key": "headerEnabled",
          "label": "Show Header",
          "type": "boolean",
          "defaultValue": true
        }
      ],
      "defaultStyles": {
        "marginBottom": "1.5sp"
      },
      "defaultProps": {
        "expression": {
          "raw": "",
          "language": "jsonata"
        },
        "itemAlias": "item",
        "borderStyle": "all",
        "headerEnabled": true
      },
      "examples": [
        {
          "name": "invoice-line-items",
          "description": "Iterate over an \"items\" array and render one row per item, with description / quantity / amount columns. Each datatable-column owns a body slot whose children are evaluated once per iteration with the item alias in scope.",
          "fragment": {
            "rootNodeId": "n-dt-items",
            "nodes": {
              "n-dt-items": {
                "id": "n-dt-items",
                "type": "datatable",
                "slots": [
                  "s-dt-items-columns"
                ],
                "props": {
                  "expression": {
                    "raw": "items",
                    "language": "jsonata"
                  },
                  "itemAlias": "item",
                  "borderStyle": "all",
                  "headerEnabled": true
                }
              },
              "n-dt-items-col-desc": {
                "id": "n-dt-items-col-desc",
                "type": "datatable-column",
                "slots": [
                  "s-dt-items-col-desc-body"
                ],
                "props": {
                  "header": "Description",
                  "width": 60
                }
              },
              "n-dt-items-col-qty": {
                "id": "n-dt-items-col-qty",
                "type": "datatable-column",
                "slots": [
                  "s-dt-items-col-qty-body"
                ],
                "props": {
                  "header": "Qty",
                  "width": 15
                }
              },
              "n-dt-items-col-amt": {
                "id": "n-dt-items-col-amt",
                "type": "datatable-column",
                "slots": [
                  "s-dt-items-col-amt-body"
                ],
                "props": {
                  "header": "Amount",
                  "width": 25
                },
                "styles": {
                  "verticalAlign": "bottom"
                }
              },
              "n-dt-items-desc-text": {
                "id": "n-dt-items-desc-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "item.description"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-dt-items-qty-text": {
                "id": "n-dt-items-qty-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "item.quantity"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-dt-items-amt-text": {
                "id": "n-dt-items-amt-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "item.amount"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-dt-items-columns": {
                "id": "s-dt-items-columns",
                "nodeId": "n-dt-items",
                "name": "columns",
                "children": [
                  "n-dt-items-col-desc",
                  "n-dt-items-col-qty",
                  "n-dt-items-col-amt"
                ]
              },
              "s-dt-items-col-desc-body": {
                "id": "s-dt-items-col-desc-body",
                "nodeId": "n-dt-items-col-desc",
                "name": "body",
                "children": [
                  "n-dt-items-desc-text"
                ]
              },
              "s-dt-items-col-qty-body": {
                "id": "s-dt-items-col-qty-body",
                "nodeId": "n-dt-items-col-qty",
                "name": "body",
                "children": [
                  "n-dt-items-qty-text"
                ]
              },
              "s-dt-items-col-amt-body": {
                "id": "s-dt-items-col-amt-body",
                "nodeId": "n-dt-items-col-amt",
                "name": "body",
                "children": [
                  "n-dt-items-amt-text"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "datatable-column",
      "label": "Data Table Column",
      "category": "layout",
      "hidden": true,
      "slots": [
        {
          "name": "body"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "padding",
        "backgroundColor",
        "border",
        "verticalAlign"
      ],
      "inspector": [
        {
          "key": "header",
          "label": "Header",
          "type": "text"
        },
        {
          "key": "width",
          "label": "Width",
          "type": "number",
          "defaultValue": 33
        }
      ],
      "defaultProps": {
        "header": "",
        "width": 33
      },
      "examples": [
        {
          "name": "minimal",
          "description": "A single datatable-column with a literal header and an empty body slot. Standalone fragment — embed inside a datatable's \"columns\" slot for it to render.",
          "fragment": {
            "rootNodeId": "n-dtcol-minimal",
            "nodes": {
              "n-dtcol-minimal": {
                "id": "n-dtcol-minimal",
                "type": "datatable-column",
                "slots": [
                  "s-dtcol-minimal-body"
                ],
                "props": {
                  "header": "Description",
                  "width": 50
                }
              }
            },
            "slots": {
              "s-dtcol-minimal-body": {
                "id": "s-dtcol-minimal-body",
                "nodeId": "n-dtcol-minimal",
                "name": "body",
                "children": []
              }
            }
          }
        }
      ]
    },
    {
      "type": "qrcode",
      "label": "QR Code",
      "icon": "qr-code",
      "category": "content",
      "hidden": false,
      "slots": [],
      "allowedChildren": {
        "mode": "none"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "marginBottom"
      ],
      "inspector": [
        {
          "key": "value.raw",
          "label": "Value",
          "type": "expression"
        },
        {
          "key": "size",
          "label": "Size",
          "type": "unit",
          "units": [
            "pt",
            "sp"
          ],
          "defaultValue": "120pt"
        }
      ],
      "defaultStyles": {
        "marginBottom": "1.5sp"
      },
      "defaultProps": {
        "value": {
          "raw": "",
          "language": "jsonata"
        },
        "size": "120pt"
      },
      "examples": [
        {
          "name": "data-bound-link",
          "description": "QR code whose value is taken from a data field — e.g. a payment URL. The value prop is an expression, not a literal string.",
          "fragment": {
            "rootNodeId": "n-qr-link",
            "nodes": {
              "n-qr-link": {
                "id": "n-qr-link",
                "type": "qrcode",
                "slots": [],
                "props": {
                  "value": {
                    "raw": "paymentLink",
                    "language": "jsonata"
                  },
                  "size": "80pt"
                }
              }
            },
            "slots": {}
          }
        },
        {
          "name": "static-string",
          "description": "QR code with a literal value. Use a JSONata string literal (single quotes) inside the raw expression.",
          "fragment": {
            "rootNodeId": "n-qr-static",
            "nodes": {
              "n-qr-static": {
                "id": "n-qr-static",
                "type": "qrcode",
                "slots": [],
                "props": {
                  "value": {
                    "raw": "'https://epistola.app'",
                    "language": "jsonata"
                  },
                  "size": "120pt"
                }
              }
            },
            "slots": {}
          }
        }
      ]
    },
    {
      "type": "placeholder",
      "label": "Placeholder",
      "icon": "square-dashed",
      "category": "layout",
      "hidden": false,
      "slots": [
        {
          "name": "default"
        },
        {
          "name": "fill",
          "editable": true
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": "all",
      "inspector": [],
      "defaultProps": {
        "name": "",
        "description": "",
        "kind": "block"
      },
      "examples": [
        {
          "name": "empty",
          "description": "A placeholder with no default content. Both slots empty — the simplest authoring shape.",
          "fragment": {
            "rootNodeId": "n-ph-empty",
            "nodes": {
              "n-ph-empty": {
                "id": "n-ph-empty",
                "type": "placeholder",
                "slots": [
                  "s-ph-empty-default",
                  "s-ph-empty-fill"
                ],
                "props": {
                  "name": "body",
                  "description": "",
                  "kind": "block"
                }
              }
            },
            "slots": {
              "s-ph-empty-default": {
                "id": "s-ph-empty-default",
                "nodeId": "n-ph-empty",
                "name": "default",
                "children": []
              },
              "s-ph-empty-fill": {
                "id": "s-ph-empty-fill",
                "nodeId": "n-ph-empty",
                "name": "fill",
                "children": []
              }
            }
          }
        },
        {
          "name": "with-default",
          "description": "A placeholder with a default text node in the `default` slot. Templates that do not fill the placeholder show this fallback. The `fill` slot starts empty.",
          "fragment": {
            "rootNodeId": "n-ph-default",
            "nodes": {
              "n-ph-default": {
                "id": "n-ph-default",
                "type": "placeholder",
                "slots": [
                  "s-ph-default-default",
                  "s-ph-default-fill"
                ],
                "props": {
                  "name": "body",
                  "description": "Body content",
                  "kind": "block"
                }
              },
              "n-ph-default-text": {
                "id": "n-ph-default-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Default body text"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-ph-default-default": {
                "id": "s-ph-default-default",
                "nodeId": "n-ph-default",
                "name": "default",
                "children": [
                  "n-ph-default-text"
                ]
              },
              "s-ph-default-fill": {
                "id": "s-ph-default-fill",
                "nodeId": "n-ph-default",
                "name": "fill",
                "children": []
              }
            }
          }
        }
      ]
    },
    {
      "type": "conditional",
      "label": "Conditional",
      "icon": "git-branch",
      "category": "logic",
      "hidden": false,
      "slots": [
        {
          "name": "body"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "backgroundColor",
        "border",
        "borderRadius",
        "keepTogether",
        "keepWithNext"
      ],
      "inspector": [
        {
          "key": "condition.raw",
          "label": "Condition",
          "type": "expression"
        },
        {
          "key": "inverse",
          "label": "Inverse (else)",
          "type": "boolean",
          "defaultValue": false
        }
      ],
      "defaultProps": {
        "condition": {
          "raw": "",
          "language": "jsonata"
        },
        "inverse": false
      },
      "examples": [
        {
          "name": "show-when-present",
          "description": "Render the body only when the data field exists. Uses the JSONata $exists() helper.",
          "fragment": {
            "rootNodeId": "n-cond-show",
            "nodes": {
              "n-cond-show": {
                "id": "n-cond-show",
                "type": "conditional",
                "slots": [
                  "s-cond-show-body"
                ],
                "props": {
                  "condition": {
                    "raw": "$exists(notes)",
                    "language": "jsonata"
                  },
                  "inverse": false
                }
              },
              "n-cond-show-text": {
                "id": "n-cond-show-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Notes: "
                          },
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "notes"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-cond-show-body": {
                "id": "s-cond-show-body",
                "nodeId": "n-cond-show",
                "name": "body",
                "children": [
                  "n-cond-show-text"
                ]
              }
            }
          }
        },
        {
          "name": "inverse-else",
          "description": "Inverted condition — body renders only when the expression is FALSEY. Useful as the \"else\" branch.",
          "fragment": {
            "rootNodeId": "n-cond-else",
            "nodes": {
              "n-cond-else": {
                "id": "n-cond-else",
                "type": "conditional",
                "slots": [
                  "s-cond-else-body"
                ],
                "props": {
                  "condition": {
                    "raw": "paid",
                    "language": "jsonata"
                  },
                  "inverse": true
                }
              },
              "n-cond-else-text": {
                "id": "n-cond-else-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Payment is due."
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-cond-else-body": {
                "id": "s-cond-else-body",
                "nodeId": "n-cond-else",
                "name": "body",
                "children": [
                  "n-cond-else-text"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "loop",
      "label": "Loop",
      "icon": "repeat",
      "category": "logic",
      "hidden": false,
      "slots": [
        {
          "name": "body"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "backgroundColor",
        "border",
        "borderRadius",
        "keepTogether",
        "keepWithNext"
      ],
      "inspector": [
        {
          "key": "expression.raw",
          "label": "Expression",
          "type": "expression"
        },
        {
          "key": "itemAlias",
          "label": "Item Alias",
          "type": "text",
          "defaultValue": "item"
        },
        {
          "key": "indexAlias",
          "label": "Index Alias",
          "type": "text"
        }
      ],
      "defaultProps": {
        "expression": {
          "raw": "",
          "language": "jsonata"
        },
        "itemAlias": "item"
      },
      "examples": [
        {
          "name": "over-array",
          "description": "Iterate over an array on the input data. Each iteration introduces \"item\" as a scoped variable referenceable inside the body slot.",
          "fragment": {
            "rootNodeId": "n-loop-items",
            "nodes": {
              "n-loop-items": {
                "id": "n-loop-items",
                "type": "loop",
                "slots": [
                  "s-loop-items-body"
                ],
                "props": {
                  "expression": {
                    "raw": "attendees",
                    "language": "jsonata"
                  },
                  "itemAlias": "item"
                }
              },
              "n-loop-items-line": {
                "id": "n-loop-items-line",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "item.name"
                            }
                          },
                          {
                            "type": "text",
                            "text": " — "
                          },
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "item.email"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-loop-items-body": {
                "id": "s-loop-items-body",
                "nodeId": "n-loop-items",
                "name": "body",
                "children": [
                  "n-loop-items-line"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "datalist",
      "label": "Data List",
      "icon": "list",
      "category": "logic",
      "hidden": false,
      "slots": [
        {
          "name": "item-template"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "backgroundColor",
        "border",
        "borderRadius",
        "keepTogether",
        "keepWithNext",
        "listItemSpacing"
      ],
      "inspector": [
        {
          "key": "expression.raw",
          "label": "Data Source",
          "type": "expression"
        },
        {
          "key": "itemAlias",
          "label": "Item Variable",
          "type": "text",
          "defaultValue": "item"
        },
        {
          "key": "indexAlias",
          "label": "Index Variable",
          "type": "text"
        },
        {
          "key": "listType",
          "label": "List Type",
          "type": "select",
          "options": [
            {
              "label": "Bullet",
              "value": "bullet"
            },
            {
              "label": "Numbered",
              "value": "decimal"
            },
            {
              "label": "Letters (a, b, c)",
              "value": "lower-alpha"
            },
            {
              "label": "Letters (A, B, C)",
              "value": "upper-alpha"
            },
            {
              "label": "Roman (i, ii, iii)",
              "value": "lower-roman"
            },
            {
              "label": "Roman (I, II, III)",
              "value": "upper-roman"
            },
            {
              "label": "No marker",
              "value": "none"
            }
          ]
        },
        {
          "key": "bulletStyle",
          "label": "Bullet Style",
          "type": "select",
          "options": [
            {
              "label": "Disc (●)",
              "value": "disc"
            },
            {
              "label": "Circle (○)",
              "value": "circle"
            },
            {
              "label": "Square (■)",
              "value": "square"
            },
            {
              "label": "Dash (–)",
              "value": "dash"
            }
          ]
        }
      ],
      "defaultStyles": {
        "listItemSpacing": "0.5sp"
      },
      "defaultProps": {
        "expression": {
          "raw": "",
          "language": "jsonata"
        },
        "itemAlias": "item",
        "listType": "bullet",
        "bulletStyle": "disc"
      },
      "examples": [
        {
          "name": "bulleted-list",
          "description": "Render an array as a bulleted list. The item-template slot holds one example item; the list expands at render time.",
          "fragment": {
            "rootNodeId": "n-datalist-bullet",
            "nodes": {
              "n-datalist-bullet": {
                "id": "n-datalist-bullet",
                "type": "datalist",
                "slots": [
                  "s-datalist-bullet-template"
                ],
                "props": {
                  "expression": {
                    "raw": "features",
                    "language": "jsonata"
                  },
                  "itemAlias": "item",
                  "listType": "bullet"
                }
              },
              "n-datalist-bullet-item": {
                "id": "n-datalist-bullet-item",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "item"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-datalist-bullet-template": {
                "id": "s-datalist-bullet-template",
                "nodeId": "n-datalist-bullet",
                "name": "item-template",
                "children": [
                  "n-datalist-bullet-item"
                ]
              }
            }
          }
        },
        {
          "name": "numbered-list",
          "description": "Same as bulleted-list but using a decimal (1., 2., 3.) marker via listType=\"decimal\".",
          "fragment": {
            "rootNodeId": "n-datalist-numbered",
            "nodes": {
              "n-datalist-numbered": {
                "id": "n-datalist-numbered",
                "type": "datalist",
                "slots": [
                  "s-datalist-numbered-template"
                ],
                "props": {
                  "expression": {
                    "raw": "steps",
                    "language": "jsonata"
                  },
                  "itemAlias": "step",
                  "listType": "decimal"
                }
              },
              "n-datalist-numbered-item": {
                "id": "n-datalist-numbered-item",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "step.title"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-datalist-numbered-template": {
                "id": "s-datalist-numbered-template",
                "nodeId": "n-datalist-numbered",
                "name": "item-template",
                "children": [
                  "n-datalist-numbered-item"
                ]
              }
            }
          }
        },
        {
          "name": "styled-bullet-list",
          "description": "A bulleted list with a non-default marker glyph via bulletStyle. Mirrors the Text component's bullet styles (disc, circle, square, dash); the same glyph renders whether the list is typed in a Text block or generated by a datalist. Note: circle/square only render with an embedding font — disc and dash are safe in standard PDFs.",
          "fragment": {
            "rootNodeId": "n-datalist-styled",
            "nodes": {
              "n-datalist-styled": {
                "id": "n-datalist-styled",
                "type": "datalist",
                "slots": [
                  "s-datalist-styled-template"
                ],
                "styles": {
                  "listItemSpacing": "1sp"
                },
                "props": {
                  "expression": {
                    "raw": "tags",
                    "language": "jsonata"
                  },
                  "itemAlias": "tag",
                  "listType": "bullet",
                  "bulletStyle": "dash"
                }
              },
              "n-datalist-styled-item": {
                "id": "n-datalist-styled-item",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "tag"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-datalist-styled-template": {
                "id": "s-datalist-styled-template",
                "nodeId": "n-datalist-styled",
                "name": "item-template",
                "children": [
                  "n-datalist-styled-item"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "separator",
      "label": "Separator",
      "icon": "minus",
      "category": "content",
      "hidden": false,
      "slots": [],
      "allowedChildren": {
        "mode": "none"
      },
      "applicableStyles": [
        "margin",
        "marginTop",
        "marginBottom"
      ],
      "inspector": [
        {
          "key": "thickness",
          "label": "Thickness",
          "type": "unit",
          "units": [
            "pt"
          ],
          "defaultValue": "1pt"
        },
        {
          "key": "width",
          "label": "Width",
          "type": "unit",
          "units": [
            "%"
          ],
          "defaultValue": "100%"
        },
        {
          "key": "color",
          "label": "Color",
          "type": "color"
        },
        {
          "key": "style",
          "label": "Style",
          "type": "select",
          "options": [
            {
              "label": "Solid",
              "value": "solid"
            },
            {
              "label": "Dashed",
              "value": "dashed"
            },
            {
              "label": "Dotted",
              "value": "dotted"
            }
          ]
        }
      ],
      "defaultStyles": {
        "marginTop": "1.5sp",
        "marginBottom": "1.5sp"
      },
      "defaultProps": {
        "thickness": "1pt",
        "width": "100%",
        "color": "#d1d5db",
        "style": "solid"
      },
      "examples": [
        {
          "name": "thin-line",
          "description": "A 1pt solid horizontal rule, full-width — the typical visual section break.",
          "fragment": {
            "rootNodeId": "n-separator-thin",
            "nodes": {
              "n-separator-thin": {
                "id": "n-separator-thin",
                "type": "separator",
                "slots": [],
                "props": {
                  "thickness": "1pt",
                  "width": "100%",
                  "color": "#d1d5db",
                  "style": "solid"
                }
              }
            },
            "slots": {}
          }
        }
      ]
    },
    {
      "type": "addressblock",
      "label": "Address Block",
      "icon": "mail",
      "category": "page",
      "hidden": false,
      "slots": [
        {
          "name": "address"
        },
        {
          "name": "aside"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": [],
      "inspector": [
        {
          "key": "standard",
          "label": "Envelope Preset",
          "type": "select",
          "options": [
            {
              "label": "DIN C5/6 Left Window",
              "value": "din-c56-left"
            },
            {
              "label": "DIN C5/6 Right Window",
              "value": "din-c56-right"
            },
            {
              "label": "Custom",
              "value": "custom"
            }
          ]
        },
        {
          "key": "align",
          "label": "Align",
          "type": "select",
          "options": [
            {
              "label": "Left",
              "value": "left"
            },
            {
              "label": "Right",
              "value": "right"
            }
          ]
        },
        {
          "key": "top",
          "label": "Top (mm)",
          "type": "number"
        },
        {
          "key": "sideDistance",
          "label": "Side Distance (mm)",
          "type": "number"
        },
        {
          "key": "addressWidth",
          "label": "Address Width (mm)",
          "type": "number"
        },
        {
          "key": "height",
          "label": "Height (mm)",
          "type": "number"
        }
      ],
      "defaultProps": {
        "standard": "din-c56-left",
        "align": "left",
        "top": 45,
        "sideDistance": 20,
        "addressWidth": 85,
        "height": 45
      },
      "maxInstancesPerDocument": 1,
      "examples": [
        {
          "name": "din-c56-left",
          "description": "Standard left-window envelope address block (DIN C5/C6) with the recipient address rendered from data fields. Singleton: only one address block per document is allowed.",
          "fragment": {
            "rootNodeId": "n-address-block",
            "nodes": {
              "n-address-block": {
                "id": "n-address-block",
                "type": "addressblock",
                "slots": [
                  "s-address-block-address",
                  "s-address-block-aside"
                ],
                "props": {
                  "standard": "din-c56-left",
                  "align": "left",
                  "top": 45,
                  "sideDistance": 20,
                  "addressWidth": 85,
                  "height": 45
                }
              },
              "n-address-block-text": {
                "id": "n-address-block-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "recipient.name"
                            }
                          },
                          {
                            "type": "hard_break"
                          },
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "recipient.address"
                            }
                          },
                          {
                            "type": "hard_break"
                          },
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "recipient.city"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-address-block-address": {
                "id": "s-address-block-address",
                "nodeId": "n-address-block",
                "name": "address",
                "children": [
                  "n-address-block-text"
                ]
              },
              "s-address-block-aside": {
                "id": "s-address-block-aside",
                "nodeId": "n-address-block",
                "name": "aside",
                "children": []
              }
            }
          }
        }
      ]
    },
    {
      "type": "pagebreak",
      "label": "Page Break",
      "icon": "file-break",
      "category": "page",
      "hidden": false,
      "slots": [],
      "allowedChildren": {
        "mode": "none"
      },
      "applicableStyles": [],
      "inspector": [],
      "examples": [
        {
          "name": "minimal",
          "description": "A hard page break — forces a new page in the rendered document.",
          "fragment": {
            "rootNodeId": "n-pagebreak",
            "nodes": {
              "n-pagebreak": {
                "id": "n-pagebreak",
                "type": "pagebreak",
                "slots": []
              }
            },
            "slots": {}
          }
        }
      ]
    },
    {
      "type": "pageheader",
      "label": "Page Header",
      "icon": "panel-top",
      "category": "page",
      "hidden": false,
      "slots": [
        {
          "name": "children"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": "all",
      "inspector": [
        {
          "key": "height",
          "label": "Height",
          "type": "unit",
          "units": [
            "pt",
            "sp"
          ],
          "defaultValue": "60pt"
        },
        {
          "key": "hideOnFirstPage",
          "label": "Hide on first page",
          "type": "boolean"
        }
      ],
      "examples": [
        {
          "name": "title-only",
          "description": "Minimal page header with a single text block, drawn at the top of the page. A header applies to what comes after it: placed at the start of the document or right after a page break it applies from that page, placed after content it takes over from the next page, and it lasts until the next header.",
          "fragment": {
            "rootNodeId": "n-pageheader",
            "nodes": {
              "n-pageheader": {
                "id": "n-pageheader",
                "type": "pageheader",
                "slots": [
                  "s-pageheader-children"
                ],
                "props": {
                  "height": "60pt"
                }
              },
              "n-pageheader-text": {
                "id": "n-pageheader-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "tenant.name"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-pageheader-children": {
                "id": "s-pageheader-children",
                "nodeId": "n-pageheader",
                "name": "children",
                "children": [
                  "n-pageheader-text"
                ]
              }
            }
          }
        },
        {
          "name": "first-page-cover",
          "description": "A taller header for a cover page. Placed directly before a second header at the start of a section, it applies to the section's first page only and the second header to the pages after it.",
          "fragment": {
            "rootNodeId": "n-pageheader-first",
            "nodes": {
              "n-pageheader-first": {
                "id": "n-pageheader-first",
                "type": "pageheader",
                "slots": [
                  "s-pageheader-first-children"
                ],
                "props": {
                  "height": "80pt"
                }
              },
              "n-pageheader-first-text": {
                "id": "n-pageheader-first-text",
                "type": "text",
                "slots": [],
                "styles": {
                  "fontSize": "18pt",
                  "fontWeight": "bold"
                },
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "tenant.name"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-pageheader-first-children": {
                "id": "s-pageheader-first-children",
                "nodeId": "n-pageheader-first",
                "name": "children",
                "children": [
                  "n-pageheader-first-text"
                ]
              }
            }
          }
        },
        {
          "name": "running-header",
          "description": "A compact running header, the second of two headers at the start of a section: it applies from the section's second page until the next header.",
          "fragment": {
            "rootNodeId": "n-pageheader-rest",
            "nodes": {
              "n-pageheader-rest": {
                "id": "n-pageheader-rest",
                "type": "pageheader",
                "slots": [
                  "s-pageheader-rest-children"
                ],
                "props": {
                  "height": "40pt",
                  "hideOnFirstPage": true
                }
              },
              "n-pageheader-rest-text": {
                "id": "n-pageheader-rest-text",
                "type": "text",
                "slots": [],
                "styles": {
                  "fontSize": "9pt"
                },
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "expression",
                            "attrs": {
                              "expression": "tenant.name"
                            }
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-pageheader-rest-children": {
                "id": "s-pageheader-rest-children",
                "nodeId": "n-pageheader-rest",
                "name": "children",
                "children": [
                  "n-pageheader-rest-text"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "pagefooter",
      "label": "Page Footer",
      "icon": "panel-bottom",
      "category": "page",
      "hidden": false,
      "slots": [
        {
          "name": "children"
        }
      ],
      "allowedChildren": {
        "mode": "all"
      },
      "applicableStyles": "all",
      "inspector": [
        {
          "key": "height",
          "label": "Height",
          "type": "unit",
          "units": [
            "pt",
            "sp"
          ],
          "defaultValue": "60pt"
        },
        {
          "key": "hideOnFirstPage",
          "label": "Hide on first page",
          "type": "boolean"
        }
      ],
      "examples": [
        {
          "name": "centered-text",
          "description": "Page footer with a single centered text block, drawn at the bottom of the page. A footer applies from the page it lands on and continues until another footer lands; a later footer landing on a page that already has one is skipped. The first footer also covers the pages before it, so a single footer anywhere covers the whole document.",
          "fragment": {
            "rootNodeId": "n-pagefooter",
            "nodes": {
              "n-pagefooter": {
                "id": "n-pagefooter",
                "type": "pagefooter",
                "slots": [
                  "s-pagefooter-children"
                ],
                "props": {
                  "height": "40pt",
                  "hideOnFirstPage": false
                }
              },
              "n-pagefooter-text": {
                "id": "n-pagefooter-text",
                "type": "text",
                "slots": [],
                "styles": {
                  "textAlign": "center",
                  "fontSize": "8pt"
                },
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Confidential — for internal use only"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-pagefooter-children": {
                "id": "s-pagefooter-children",
                "nodeId": "n-pagefooter",
                "name": "children",
                "children": [
                  "n-pagefooter-text"
                ]
              }
            }
          }
        }
      ]
    },
    {
      "type": "image",
      "label": "Image",
      "icon": "image",
      "category": "content",
      "hidden": false,
      "slots": [],
      "allowedChildren": {
        "mode": "none"
      },
      "applicableStyles": [
        "padding",
        "margin",
        "marginBottom"
      ],
      "inspector": [
        {
          "key": "alt",
          "label": "Alt Text",
          "type": "text"
        },
        {
          "key": "decorative",
          "label": "Decorative Image",
          "type": "boolean",
          "defaultValue": false
        },
        {
          "key": "width",
          "label": "Width",
          "type": "unit",
          "units": [
            "pt",
            "sp",
            "%"
          ]
        },
        {
          "key": "height",
          "label": "Height",
          "type": "unit",
          "units": [
            "pt",
            "sp",
            "%"
          ]
        },
        {
          "key": "aspectRatioLocked",
          "label": "Lock Aspect Ratio",
          "type": "boolean",
          "defaultValue": true
        }
      ],
      "defaultStyles": {
        "marginBottom": "1.5sp"
      },
      "defaultProps": {
        "imageKey": null,
        "catalogKey": null,
        "alt": "",
        "decorative": false,
        "width": "",
        "height": "",
        "aspectRatioLocked": true
      },
      "examples": [
        {
          "name": "placeholder",
          "description": "An empty image node with no assigned image. The imageKey is null, so the renderer shows a placeholder. Set imageKey to the key of an image resource and width/height to render the actual image.",
          "fragment": {
            "rootNodeId": "n-image-placeholder",
            "nodes": {
              "n-image-placeholder": {
                "id": "n-image-placeholder",
                "type": "image",
                "slots": [],
                "props": {
                  "imageKey": null,
                  "alt": "",
                  "width": "",
                  "height": "",
                  "aspectRatioLocked": true
                }
              }
            },
            "slots": {}
          }
        },
        {
          "name": "with-asset",
          "description": "An image node referencing a real image (the Epistola logo from the demo catalog: key 01966a00-0000-7000-8000-000000000001). The imageKey is the image resource's key within its catalog, and the catalogKey records which catalog the image lives in, so the reference works across catalogs. Width and height are set in points — the renderer fetches the image binary when producing the PDF.",
          "fragment": {
            "rootNodeId": "n-image-logo",
            "nodes": {
              "n-image-logo": {
                "id": "n-image-logo",
                "type": "image",
                "slots": [],
                "props": {
                  "imageKey": "01966a00-0000-7000-8000-000000000001",
                  "catalogKey": "epistola-demo",
                  "alt": "Epistola Logo",
                  "width": "80pt",
                  "height": "20pt",
                  "aspectRatioLocked": true
                }
              }
            },
            "slots": {}
          }
        }
      ]
    },
    {
      "type": "stencil",
      "label": "Stencil",
      "icon": "puzzle",
      "category": "layout",
      "hidden": false,
      "slots": [
        {
          "name": "children"
        }
      ],
      "allowedChildren": {
        "mode": "denylist",
        "types": [
          "root"
        ]
      },
      "applicableStyles": "all",
      "inspector": [],
      "defaultProps": {
        "stencilKey": null,
        "catalogKey": null
      },
      "examples": [
        {
          "name": "with-placeholder",
          "description": "A stencil instance (as it appears inside a template) containing one placeholder named \"body\". The placeholder owns two slots: `default` (set by the stencil author at publish time) and `fill` (the template override; empty here, so the renderer falls back to the default). Replacing or adding to `fill` overrides the default; clearing `fill` reverts to the default.",
          "fragment": {
            "rootNodeId": "n-stencil-letter",
            "nodes": {
              "n-stencil-letter": {
                "id": "n-stencil-letter",
                "type": "stencil",
                "slots": [
                  "s-stencil-letter-children"
                ],
                "props": {
                  "stencilKey": "letter-shell",
                  "catalogKey": "epistola-demo"
                }
              },
              "n-stencil-letter-ph": {
                "id": "n-stencil-letter-ph",
                "type": "placeholder",
                "slots": [
                  "s-stencil-letter-ph-default",
                  "s-stencil-letter-ph-fill"
                ],
                "props": {
                  "name": "body",
                  "description": "Body content",
                  "kind": "block"
                }
              },
              "n-stencil-letter-default-text": {
                "id": "n-stencil-letter-default-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Default body text"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-stencil-letter-children": {
                "id": "s-stencil-letter-children",
                "nodeId": "n-stencil-letter",
                "name": "children",
                "children": [
                  "n-stencil-letter-ph"
                ]
              },
              "s-stencil-letter-ph-default": {
                "id": "s-stencil-letter-ph-default",
                "nodeId": "n-stencil-letter-ph",
                "name": "default",
                "children": [
                  "n-stencil-letter-default-text"
                ]
              },
              "s-stencil-letter-ph-fill": {
                "id": "s-stencil-letter-ph-fill",
                "nodeId": "n-stencil-letter-ph",
                "name": "fill",
                "children": []
              }
            }
          }
        },
        {
          "name": "with-overridden-placeholder",
          "description": "Same stencil as `with-placeholder`, but the template has overridden the placeholder by populating its `fill` slot. The renderer prefers `fill` over `default` when fill is non-empty, so this stencil instance renders \"Custom body — overridden\" instead of the default. Clearing `fill` would revert to the default.",
          "fragment": {
            "rootNodeId": "n-stencil-letter-ov",
            "nodes": {
              "n-stencil-letter-ov": {
                "id": "n-stencil-letter-ov",
                "type": "stencil",
                "slots": [
                  "s-stencil-letter-ov-children"
                ],
                "props": {
                  "stencilKey": "letter-shell",
                  "catalogKey": "epistola-demo"
                }
              },
              "n-stencil-letter-ov-ph": {
                "id": "n-stencil-letter-ov-ph",
                "type": "placeholder",
                "slots": [
                  "s-stencil-letter-ov-ph-default",
                  "s-stencil-letter-ov-ph-fill"
                ],
                "props": {
                  "name": "body",
                  "description": "Body content",
                  "kind": "block"
                }
              },
              "n-stencil-letter-ov-default-text": {
                "id": "n-stencil-letter-ov-default-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Default body text"
                          }
                        ]
                      }
                    ]
                  }
                }
              },
              "n-stencil-letter-ov-fill-text": {
                "id": "n-stencil-letter-ov-fill-text",
                "type": "text",
                "slots": [],
                "props": {
                  "content": {
                    "type": "doc",
                    "content": [
                      {
                        "type": "paragraph",
                        "content": [
                          {
                            "type": "text",
                            "text": "Custom body — overridden"
                          }
                        ]
                      }
                    ]
                  }
                }
              }
            },
            "slots": {
              "s-stencil-letter-ov-children": {
                "id": "s-stencil-letter-ov-children",
                "nodeId": "n-stencil-letter-ov",
                "name": "children",
                "children": [
                  "n-stencil-letter-ov-ph"
                ]
              },
              "s-stencil-letter-ov-ph-default": {
                "id": "s-stencil-letter-ov-ph-default",
                "nodeId": "n-stencil-letter-ov-ph",
                "name": "default",
                "children": [
                  "n-stencil-letter-ov-default-text"
                ]
              },
              "s-stencil-letter-ov-ph-fill": {
                "id": "s-stencil-letter-ov-ph-fill",
                "nodeId": "n-stencil-letter-ov-ph",
                "name": "fill",
                "children": [
                  "n-stencil-letter-ov-fill-text"
                ]
              }
            }
          }
        }
      ],
      "parameters": {
        "kind": "dynamic"
      }
    }
  ]
};

export const styleRegistry: StyleRegistry = {
  "schemaVersion": 1,
  "groups": [
    {
      "name": "typography",
      "label": "Typography",
      "properties": [
        {
          "key": "fontFamily",
          "label": "Font",
          "type": "select",
          "inheritable": true,
          "options": []
        },
        {
          "key": "fontSize",
          "label": "Size",
          "type": "unit",
          "inheritable": true,
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "fontWeight",
          "label": "Weight",
          "type": "select",
          "inheritable": true,
          "options": [
            {
              "label": "Normal",
              "value": "400"
            },
            {
              "label": "Medium",
              "value": "500"
            },
            {
              "label": "Semi Bold",
              "value": "600"
            },
            {
              "label": "Bold",
              "value": "700"
            }
          ]
        },
        {
          "key": "fontStyle",
          "label": "Style",
          "type": "select",
          "inheritable": true,
          "options": [
            {
              "label": "Normal",
              "value": "normal"
            },
            {
              "label": "Italic",
              "value": "italic"
            }
          ]
        },
        {
          "key": "color",
          "label": "Color",
          "type": "color",
          "inheritable": true
        },
        {
          "key": "lineHeight",
          "label": "Line Height",
          "type": "number",
          "inheritable": true
        },
        {
          "key": "letterSpacing",
          "label": "Letter Spacing",
          "type": "unit",
          "inheritable": true,
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "textAlign",
          "label": "Text Align",
          "type": "select",
          "inheritable": true,
          "options": [
            {
              "label": "Left",
              "value": "left"
            },
            {
              "label": "Center",
              "value": "center"
            },
            {
              "label": "Right",
              "value": "right"
            },
            {
              "label": "Justify",
              "value": "justify"
            }
          ]
        }
      ]
    },
    {
      "name": "spacing",
      "label": "Spacing",
      "properties": [
        {
          "key": "padding",
          "label": "Padding",
          "type": "spacing",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "margin",
          "label": "Margin",
          "type": "spacing",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "listItemSpacing",
          "label": "List Item Spacing",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ],
          "inheritable": true
        },
        {
          "key": "marginTop",
          "label": "Top Margin",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "marginRight",
          "label": "Right Margin",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "marginBottom",
          "label": "Bottom Margin",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "marginLeft",
          "label": "Left Margin",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "paddingTop",
          "label": "Top Padding",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "paddingRight",
          "label": "Right Padding",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "paddingBottom",
          "label": "Bottom Padding",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        },
        {
          "key": "paddingLeft",
          "label": "Left Padding",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ]
        }
      ]
    },
    {
      "name": "background",
      "label": "Background",
      "properties": [
        {
          "key": "backgroundColor",
          "label": "Background",
          "type": "color"
        }
      ]
    },
    {
      "name": "borders",
      "label": "Borders",
      "properties": [
        {
          "key": "border",
          "label": "Border",
          "type": "border",
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "borderTop",
          "label": "Top Border",
          "type": "border",
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "borderRight",
          "label": "Right Border",
          "type": "border",
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "borderBottom",
          "label": "Bottom Border",
          "type": "border",
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "borderLeft",
          "label": "Left Border",
          "type": "border",
          "units": [
            "pt",
            "sp"
          ]
        },
        {
          "key": "borderRadius",
          "label": "Radius",
          "type": "unit",
          "units": [
            "pt",
            "sp"
          ]
        }
      ]
    },
    {
      "name": "sizing",
      "label": "Sizing",
      "properties": [
        {
          "key": "width",
          "label": "Width",
          "type": "unit",
          "units": [
            "%",
            "sp",
            "pt"
          ]
        },
        {
          "key": "minHeight",
          "label": "Min Height",
          "description": "The least height of the box. It grows with its content when that is taller; it never clips.",
          "type": "unit",
          "units": [
            "sp",
            "pt"
          ],
          "includedInAll": false
        }
      ]
    },
    {
      "name": "alignment",
      "label": "Alignment",
      "properties": [
        {
          "key": "verticalAlign",
          "label": "Vertical Align",
          "description": "Where the content sits in a box that is taller than it, such as a table cell or a column in a row of equal-height columns.",
          "type": "select",
          "includedInAll": false,
          "options": [
            {
              "label": "Top",
              "value": "top"
            },
            {
              "label": "Middle",
              "value": "middle"
            },
            {
              "label": "Bottom",
              "value": "bottom"
            }
          ]
        }
      ]
    },
    {
      "name": "pageFlow",
      "label": "Page Flow",
      "properties": [
        {
          "key": "keepTogether",
          "label": "Keep Together",
          "type": "boolean"
        },
        {
          "key": "keepWithNext",
          "label": "Keep With Next",
          "type": "boolean"
        }
      ]
    }
  ]
};

export const componentTypes = [
  "root",
  "text",
  "richTextVariable",
  "container",
  "columns",
  "table",
  "datatable",
  "datatable-column",
  "qrcode",
  "placeholder",
  "conditional",
  "loop",
  "datalist",
  "separator",
  "addressblock",
  "pagebreak",
  "pageheader",
  "pagefooter",
  "image",
  "stencil"
] as const;

export type ComponentType = (typeof componentTypes)[number];

export const styleKeys = [
  "fontFamily",
  "fontSize",
  "fontWeight",
  "fontStyle",
  "color",
  "lineHeight",
  "letterSpacing",
  "textAlign",
  "padding",
  "margin",
  "listItemSpacing",
  "marginTop",
  "marginRight",
  "marginBottom",
  "marginLeft",
  "paddingTop",
  "paddingRight",
  "paddingBottom",
  "paddingLeft",
  "backgroundColor",
  "border",
  "borderTop",
  "borderRight",
  "borderBottom",
  "borderLeft",
  "borderRadius",
  "width",
  "minHeight",
  "verticalAlign",
  "keepTogether",
  "keepWithNext"
] as const;

export type StyleKey = (typeof styleKeys)[number];

/** Style keys that `applicableStyles: "all"` leaves out (`includedInAll: false`): they apply only where listed by key. */
export const optInStyleKeys: readonly string[] = [
  "minHeight",
  "verticalAlign"
];

/**
 * Whether a component's (or a style map's) `applicableStyles` accepts the registry style `key`, as the
 * portable validator decides it. `"all"` accepts every key except the opt-in ones; a list accepts
 * a key that one of its entries is a prefix of, so `padding` covers `paddingTop` and `border`
 * covers `borderRadius`. A key the style registry does not define is not checked here.
 */
export function isStyleApplicable(key: string, applicableStyles: 'all' | readonly string[]): boolean {
  if (applicableStyles === 'all') return !optInStyleKeys.includes(key);
  return applicableStyles.some((entry) => key.startsWith(entry));
}
